# 8452-minimal-repro
